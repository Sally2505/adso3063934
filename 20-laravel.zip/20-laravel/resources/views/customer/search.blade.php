@if($pets->count() == 0)
<tr>
    <td colspan="10" class="text-center text-white font-bold py-4">
        No pets found
    </td>
</tr>
@else
@foreach($pets as $pet)
<tr class="border-b border-[#f50b6c70] hover:bg-[#ffa6cb70] transition">

    <td class="hidden md:table-cell">{{ $pet->id }}</td>

    <td class="py-2">
        <div class="avatar">
            <div class="w-14 rounded-full overflow-hidden bg-gray-300">
                <img src="{{ asset('images/'.$pet->image) }}" class="object-cover w-full h-full" />
            </div>
        </div>
    </td>

    <td class="text-white font-semibold">{{ $pet->name }}</td>
    <td class="hidden md:table-cell">{{ $pet->kind }}</td>
    <td class="hidden md:table-cell">{{ $pet->weight }} kg</td>
    <td class="hidden md:table-cell">{{ $pet->age }}</td>
    <td class="hidden md:table-cell">{{ $pet->breed }}</td>

    <td>
        @if($pet->status)
            <div class="badge bg-green-600/60 text-white border-none">Adopted</div>
        @else
            <div class="badge bg-yellow-600/60 text-white border-none">Waiting</div>
        @endif
    </td>

    <td>
        @if($pet->active)
            <div class="badge bg-green-600/60 text-white border-none">Active</div>
        @else
            <div class="badge bg-red-600/60 text-white border-none">Inactive</div>
        @endif
    </td>

    <td class="py-4 flex justify-center gap-4">

        {{-- Adopt icon --}}
        <a href="#" class="btn_adopt text-white hover:text-[#ff78c9]" data-id="{{ $pet->id }}">
            <svg xmlns="http://www.w3.org/2000/svg" class="size-6" fill="currentColor" viewBox="0 0 256 256">
                <path d="M230.33,141.06a24.34..."></path>
            </svg>
        </a>

    </td>

</tr>
@endforeach
@endif
