<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>All Pets</title> 
</head>

<body>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th> 
                <th>Kind</th> 
                <th>Breed</th> 
                <th>Age</th> 
                <th>Photo</th>
            </tr>
        </thead>
        <tbody>
            
            <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pet->id); ?></td>
                <td><?php echo e($pet->name); ?></td>
                <td><?php echo e($pet->kind); ?></td>
                <td><?php echo e($pet->breed); ?></td>
                <td><?php echo e($pet->age); ?></td>
                <td>
                    
                    <img src="<?php echo e(public_path().'/images/'.$pet->image); ?>" width="50px">
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html><?php /**PATH C:\Users\yeiso\Downloads\20-laravel\resources\views/pets/excel.blade.php ENDPATH**/ ?>