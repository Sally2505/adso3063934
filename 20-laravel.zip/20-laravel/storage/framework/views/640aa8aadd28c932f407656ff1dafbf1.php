<?php if($pets->count() == 0): ?>
<tr class="h-24">
    <td colspan="9" class="text-center align-middle py-4 text-white font-bold">
        No pets found
    </td>
</tr>
<?php else: ?>
<?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="border-b border-[#f1a8b380] hover:bg-[#f1a8b840] transition">

    <td class="hidden md:table-cell"><?php echo e($pet->id); ?></td>

    <td class="py-2 whitespace-nowrap">
        <div class="avatar">
            <div class="w-14 md:w-16 rounded-full bg-gray-200 overflow-hidden">
                <img src="<?php echo e(asset('images/'.$pet->image)); ?>" loading="lazy" width="64" height="64"
                    class="object-cover w-full h-full transition-opacity duration-300" />
            </div>
        </div>
    </td>

    <td class="py-3 font-medium text-white whitespace-nowrap"><?php echo e($pet->name); ?></td>
    <td class="hidden md:table-cell"><?php echo e($pet->kind); ?></td>
    <td class="hidden md:table-cell"><?php echo e($pet->weight); ?> kg</td>
    <td class="hidden md:table-cell"><?php echo e($pet->age); ?></td>
    <td class="hidden md:table-cell"><?php echo e($pet->breed); ?></td>

    <td class="hidden md:table-cell">
        <?php if($pet->status): ?>
        <div class="badge bg-[#07e91e60] text-white border-none">Adopted</div>
        <?php else: ?>
        <div class="badge bg-[#e9d50760] text-white border-none">Waiting</div>
        <?php endif; ?>
    </td>

    <td class="hidden md:table-cell">
        <?php if($pet->active): ?>
        <div class="badge bg-[#07e91e60] text-white border-none">Active</div>
        <?php else: ?>
        <div class="badge bg-[#e9070760] text-white border-none">Inactive</div>
        <?php endif; ?>
    </td>

    <td class="py-4 flex justify-center gap-4 md:gap-3 whitespace-nowrap">
        <a href="#" class="btn_adopt text-[#ffffff] hover:text-[#ff78c9]" data-id="<?php echo e($pet->id); ?>"
            data-name="<?php echo e($pet->name); ?>">
            Adopt
        </a>
    </td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td colspan="9">
        <?php echo e($pets->links('layouts.pagination')); ?>

    </td>
</tr>
<?php endif; ?>
<?php /**PATH C:\Escritorio\adso3063934\20-laravel\resources\views/pets/search.blade.php ENDPATH**/ ?>