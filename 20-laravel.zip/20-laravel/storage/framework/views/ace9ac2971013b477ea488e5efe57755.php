<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Pets Report</title>
<style>
table {
border: 2px solid #aaa;
border-collapse: collapse
}
table th, table td {
font-family: sans-serif;
font-size: 10px;
border: 2px solid #ccc;
padding: 4px;
}
table tr:nth-child(odd) {
background-color: #eee;
}
table th {
background-color: #666;
color: #fff;
text-align: center;
}
</style>
</head>
<body>
<h1>Reporte de Mascotas (Pets)</h1>
<table>
<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Kind</th>
<th>Breed</th>
<th>Age</th>
<th>Active</th>
<th>Image</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($pet->id); ?></td>
<td><?php echo e($pet->name); ?></td>
<td><?php echo e($pet->kind); ?></td>
<td><?php echo e($pet->breed); ?></td>
<td><?php echo e($pet->age); ?></td>
<td><?php echo e($pet->active ? 'Yes' : 'No'); ?></td>
<td>
<?php
// 1. Lógica para el placeholder: usar 'no-image.png' si $pet->image está vacío
$imagePath = $pet->image ? $pet->image : 'no-image.png';

                    // 2. Lógica para la extensión: se basa en el archivo que realmente se va a cargar ($imagePath)
                    $extension = substr($imagePath, -4);
                ?>
                
                <?php if($extension != 'webp' && $extension != '.svg'): ?>
                    
                    <img src="<?php echo e(public_path().'/images/'.$imagePath); ?>" width="96px">
                <?php else: ?>
                    Webp|SVG
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


</body>
</html><?php /**PATH C:\Users\yeiso\Downloads\20-laravel\resources\views/pets/pdf.blade.php ENDPATH**/ ?>