<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>All Users</title>
    <style>
        table {
            border: 2px solid #aaa;
            border-collapse: collapse
        }
        table th, table td {
            font-family: sans-serif;
            font-size: 10px;
            border: 2px solid #ccc;
            padding: 4px;
        }
        table tr:nth-child(odd) {
            background-color: #eee;
        }
        table th {
            background-color: #666;
            color: #fff;
            text-align: center;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Gender</th>
                <th>Age</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Active</th>
                <th>Photo</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->fullname); ?></td>
                <td><?php echo e($user->gender); ?></td>
                <td><?php echo e(Carbon\Carbon::parse($user->birthdate)->age); ?> years old</td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->role); ?></td>
                <td>
                    <?php if($user->active == 1): ?>
                        Active
                    <?php else: ?>
                        Inactive
                    <?php endif; ?>
                </td>

                <td>
                    <?php
                        $extension = substr($user->photo, -4);
                    ?>
                    <?php if($extension != 'webp' && $extension != '.svg'): ?>
                        <img src="<?php echo e(public_path().'/images/'.$user->photo); ?>" width="96px">
                    <?php else: ?>
                        Webp|SVG
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Escritorio\adso3063934\20-laravel\resources\views/users/pdf.blade.php ENDPATH**/ ?>